package com.timetable.exception;

public class AuthenticationException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public AuthenticationException() {
        super();
    }

    public AuthenticationException(String username) {
        super("Authentication failed for user : " + username);
    }

}